//#include <atmel_start.h>
#include "atmel_start.h"
#include <avr/sleep.h>

extern volatile uint8_t I2C_0_slave_address;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		if (!I2C_0_slave_address)
		{
			sleep_cpu();
		}
	}
}
